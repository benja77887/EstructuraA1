from models import Estudiante, CAMPOS_Estudiante
from shared.json_manager import GestorJSON
from shared.herramientas import es_email_valido

gestor = GestorJSON("data/estudiantes.json")

# TUPLAS de configuración: fijas, nadie las modifica en tiempo de ejecución
CAMPOS_OBLIGATORIOS = ("nombre", "apellido", "email")
CAMPOS_BUSCABLES = ("nombre", "apellido", "email", "telefono", "ciudad")


# ===================== AYUDAS INTERNAS =====================

def emails_registrados(excepto_id=None):
    """CONJUNTO con los emails ya usados. Sirve para detectar duplicados al instante."""
    return {
        registro["email"].lower()
        for registro in gestor.leer()
        if registro["id"] != excepto_id
    }


def siguiente_id():
    ids = [registro["id"] for registro in gestor.leer()]
    return max(ids) + 1 if ids else 1


# ===================== C · CREATE =====================

def crear_estudiante(datos):
    """datos: diccionario con las claves de CAMPOS_Estudiante. Devuelve (exito, mensaje)."""
    try:
        # 1) Normalizo: un diccionario con todos los campos, sin espacios sobrantes
        valores = {campo: str(datos.get(campo, "")).strip() for campo in CAMPOS_Estudiante}

        # 2) Reviso obligatorios recorriendo la TUPLA
        faltantes = [campo for campo in CAMPOS_OBLIGATORIOS if not valores[campo]]
        if faltantes:
            return False, f"Faltan campos obligatorios: {', '.join(faltantes)}"

        # 3) Formato del email
        if not es_email_valido(valores["email"]):
            return False, f"El email '{valores['email']}' no tiene un formato válido"

        # 4) Duplicado: búsqueda instantánea dentro del CONJUNTO
        if valores["email"].lower() in emails_registrados():
            return False, "Ese email ya está registrado"

        # 5) Creo el objeto del Modelo. ** convierte el diccionario en argumentos
        estudiante = Estudiante(siguiente_id(), **valores)

        # 6) Agrego a la LISTA y guardo
        registros = gestor.leer()
        registros.append(estudiante.a_diccionario())
        if not gestor.guardar(registros):
            return False, "No se pudo escribir el archivo"

        return True, f"Estudiante {estudiante.obtener_nombre_completo()} creado con id {estudiante.id}"

    except Exception as error:
        return False, f"Error inesperado: {error}"


# ===================== R · READ =====================

def obtener_todos():
    """LISTA de objetos estudiante."""
    return [Estudiante.desde_diccionario(registro) for registro in gestor.leer()]


def obtener_por_id(id_estudiante):
    for estudiante in obtener_todos():
        if estudiante.id == id_estudiante:
            return estudiante
    return None


# ===================== S · SEARCH =====================

def buscar_estudiantes(termino):
    """Búsqueda lineal: revisa registro por registro los campos de CAMPOS_BUSCABLES."""
    termino = termino.strip().lower()
    if not termino:
        return []

    encontrados = []
    for registro in gestor.leer():
        for campo in CAMPOS_BUSCABLES:                 # recorro la TUPLA de campos
            if termino in str(registro.get(campo, "")).lower():
                encontrados.append(Estudiante.desde_diccionario(registro))
                break                                   # ya coincidió: paso al siguiente cliente
    return encontrados


# ===================== U · UPDATE =====================

def actualizar_estudiante(id_estudiante, cambios):
    """cambios: diccionario solo con los campos que se quieren modificar."""
    try:
        # DIFERENCIA DE CONJUNTOS: ¿mandaron algún campo que no existe?
        desconocidos = set(cambios) - set(CAMPOS_Estudiante)
        if desconocidos:
            return False, f"Campos no válidos: {', '.join(sorted(desconocidos))}"

        if not cambios:
            return False, "No se indicó ningún cambio"

        if "email" in cambios:
            if not es_email_valido(cambios["email"]):
                return False, "El email no tiene un formato válido"
            if cambios["email"].lower() in emails_registrados(excepto_id=id_estudiante):
                return False, "Ese email ya lo usa otro cliente"

        registros = gestor.leer()
        posicion = None
        for indice, registro in enumerate(registros):   # enumerate me da índice y valor
            if registro["id"] == id_estudiante:
                posicion = indice
                break

        if posicion is None:
            return False, f"No existe un cliente con id {id_estudiante}"

        registros[posicion].update(cambios)             # actualizo el diccionario en su lugar
        gestor.guardar(registros)
        return True, f"Estudiante {id_estudiante} actualizado ({len(cambios)} campo/s)"

    except Exception as error:
        return False, f"Error inesperado: {error}"


# ===================== D · DELETE =====================

def eliminar_estudiante(id_estudiante):
    registros = gestor.leer()
    # Construyo una LISTA NUEVA sin ese registro: nunca borro mientras recorro
    quedan = [registro for registro in registros if registro["id"] != id_estudiante]

    if len(quedan) == len(registros):
        return False, f"No existe un cliente con id {id_estudiante}"

    gestor.guardar(quedan)
    return True, f"Estudiante {id_estudiante} eliminado"


# ===================== EXTRA: estadísticas con conjuntos =====================

def estadisticas():
    """Devuelve un DICCIONARIO de resumen. Práctica pura de colecciones."""
    registros = gestor.leer()
    ciudades = {r.get("ciudad", "").title() for r in registros if r.get("ciudad")}
    dominios = {r["email"].split("@")[1].lower() for r in registros if "@" in r["email"]}
    sin_telefono = [r["nombre"] for r in registros if not r.get("telefono")]

    return {
        "total": len(registros),
        "ciudades": sorted(ciudades),
        "dominios": sorted(dominios),
        "sin_telefono": sin_telefono,
    }


# ===================== Agregar Notas =====================

def agregar_nota(id_estudiante, materia, nota):
    """
    Agrega una nota a un estudiante.
    La nota debe ser un número entre 0 y 20.
    Devuelve (True, mensaje) o (False, mensaje).
    """
    try:
        try:
            nota = float(nota)
        except (TypeError, ValueError):
            return False, "La nota debe ser un número"

        if not (0 <= nota <= 20):
            return False, "La nota debe estar entre 0 y 20"

        materia = str(materia).strip()
        if not materia:
            return False, "La materia no puede estar vacía"

        registros = gestor.leer()
        posicion = None
        for indice, registro in enumerate(registros):
            if registro["id"] == id_estudiante:
                posicion = indice
                break

        if posicion is None:
            return False, f"No existe un estudiante con id {id_estudiante}"

        if "notas" not in registros[posicion] or not isinstance(registros[posicion]["notas"], dict):
            registros[posicion]["notas"] = {}

        registros[posicion]["notas"][materia] = nota

        if not gestor.guardar(registros):
            return False, "No se pudo escribir el archivo"

        return True, f"Nota {nota} agregada en '{materia}' al estudiante {id_estudiante}"

    except Exception as error:
        return False, f"Error inesperado: {error}"


# ===================== Materias Ofertadas =====================

def materias_ofertadas():
    """Devuelve el SET con todas las materias inscritas por todos los estudiantes, sin repetir."""
    materias = set()
    for registro in gestor.leer():
        notas = registro.get("notas", {})
        if isinstance(notas, dict):
            materias.update(notas.keys())
    return materias


# ===================== Estudiantes en Común =====================

def estudiantes_en_comun(id_a, id_b):
    """
    Usa la intersección de conjuntos para mostrar las materias que dos estudiantes comparten.
    Devuelve (True, set_materias) o (False, mensaje).
    """
    registros = gestor.leer()
    notas_a = None
    notas_b = None

    for registro in registros:
        if registro["id"] == id_a:
            notas_a = registro.get("notas", {})
        if registro["id"] == id_b:
            notas_b = registro.get("notas", {})

    if notas_a is None:
        return False, f"No existe un estudiante con id {id_a}"
    if notas_b is None:
        return False, f"No existe un estudiante con id {id_b}"

    if not isinstance(notas_a, dict):
        notas_a = {}
    if not isinstance(notas_b, dict):
        notas_b = {}

    comunes = set(notas_a.keys()) & set(notas_b.keys())
    return True, comunes


# ===================== Promedio =====================

def promedio_estudiante(id_estudiante):
    """Calcula el promedio de notas de un estudiante. Devuelve (True, promedio) o (False, mensaje)."""
    for registro in gestor.leer():
        if registro["id"] == id_estudiante:
            notas = registro.get("notas", {})
            if not isinstance(notas, dict) or not notas:
                return False, "El estudiante no tiene notas registradas"
            valores = [float(v) for v in notas.values()]
            promedio = sum(valores) / len(valores)
            return True, round(promedio, 2)
    return False, f"No existe un estudiante con id {id_estudiante}"
