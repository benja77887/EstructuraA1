from views import (
    crear_estudiante,
    obtener_todos,
    obtener_por_id,
    buscar_estudiantes,
    actualizar_estudiante,
    eliminar_estudiante,
    estadisticas,
    agregar_nota,
    materias_ofertadas,
    estudiantes_en_comun,
    promedio_estudiante,
)


def mostrar_menu():
    print("\n========== GESTIÓN DE ESTUDIANTES ==========")
    print("1. Crear estudiante")
    print("2. Listar todos los estudiantes")
    print("3. Buscar estudiante")
    print("4. Actualizar estudiante")
    print("5. Eliminar estudiante")
    print("6. Ver estadísticas")
    print("7. Agregar nota")
    print("8. Ver promedio")
    print("9. Materias en común")
    print("10. Materias ofertadas")
    print("0. Salir")
    print("============================================")


def pedir_datos_estudiante():
    datos = {}
    datos["nombre"] = input("Nombre: ").strip()
    datos["apellido"] = input("Apellido: ").strip()
    datos["email"] = input("Email: ").strip()
    datos["telefono"] = input("Teléfono (opcional): ").strip()
    datos["ciudad"] = input("Ciudad (opcional): ").strip()
    return datos


def main():
    while True:
        mostrar_menu()
        opcion = input("Elige una opción: ").strip()

        if opcion == "1":
            datos = pedir_datos_estudiante()
            exito, mensaje = crear_estudiante(datos)
            print(mensaje)

        elif opcion == "2":
            estudiantes = obtener_todos()
            if not estudiantes:
                print("No hay estudiantes registrados.")
            else:
                for est in estudiantes:
                    print(f"  ID {est.id}: {est.obtener_nombre_completo()} - {est.email}")

        elif opcion == "3":
            termino = input("Término de búsqueda: ").strip()
            encontrados = buscar_estudiantes(termino)
            if not encontrados:
                print("No se encontraron estudiantes.")
            else:
                for est in encontrados:
                    print(f"  ID {est.id}: {est.obtener_nombre_completo()} - {est.email}")

        elif opcion == "4":
            try:
                id_est = int(input("ID del estudiante a actualizar: "))
            except ValueError:
                print("ID inválido.")
                continue
            print("Deja en blanco los campos que no quieras cambiar.")
            cambios = {}
            for campo in ("nombre", "apellido", "email", "telefono", "ciudad"):
                valor = input(f"{campo.capitalize()}: ").strip()
                if valor:
                    cambios[campo] = valor
            exito, mensaje = actualizar_estudiante(id_est, cambios)
            print(mensaje)

        elif opcion == "5":
            try:
                id_est = int(input("ID del estudiante a eliminar: "))
            except ValueError:
                print("ID inválido.")
                continue
            exito, mensaje = eliminar_estudiante(id_est)
            print(mensaje)

        elif opcion == "6":
            stats = estadisticas()
            print(f"Total de estudiantes: {stats['total']}")
            print(f"Ciudades: {', '.join(stats['ciudades']) or 'Ninguna'}")
            print(f"Dominios de email: {', '.join(stats['dominios']) or 'Ninguno'}")
            print(f"Sin teléfono: {', '.join(stats['sin_telefono']) or 'Ninguno'}")

        elif opcion == "7":  # Agregar nota
            try:
                id_est = int(input("ID del estudiante: "))
            except ValueError:
                print("ID inválido.")
                continue
            materia = input("Materia: ").strip()
            nota = input("Nota (0-20): ").strip()
            exito, mensaje = agregar_nota(id_est, materia, nota)
            print(mensaje)

        elif opcion == "8":  # Ver promedio
            try:
                id_est = int(input("ID del estudiante: "))
            except ValueError:
                print("ID inválido.")
                continue
            exito, resultado = promedio_estudiante(id_est)
            if exito:
                print(f"Promedio del estudiante {id_est}: {resultado}")
            else:
                print(resultado)

        elif opcion == "9":  # Materias en común
            try:
                id_a = int(input("ID del primer estudiante: "))
                id_b = int(input("ID del segundo estudiante: "))
            except ValueError:
                print("ID inválido.")
                continue
            exito, resultado = estudiantes_en_comun(id_a, id_b)
            if exito:
                if resultado:
                    print(f"Materias en común: {', '.join(sorted(resultado))}")
                else:
                    print("No tienen materias en común.")
            else:
                print(resultado)

        elif opcion == "10":  # Materias ofertadas
            materias = materias_ofertadas()
            if materias:
                print(f"Materias ofertadas: {', '.join(sorted(materias))}")
            else:
                print("Aún no hay materias registradas.")

        elif opcion == "0":
            print("¡Hasta luego!")
            break

        else:
            print("Opción no válida. Intenta de nuevo.")


if __name__ == "__main__":
    main()
